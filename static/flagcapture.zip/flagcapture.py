# Flag Capture
# By Al Sweigart al@inventwithpython.com
# http://inventwithpython.com/blog
# Released under a "Simplified BSD" license

# The objective of the game is to touch the "target flag" shown in the lower left corner.
# When in blue mode, you can safely touch blue flags but red flags damage you.
# When in red mode, you can safely touch red flags but blue flags damage you.

# This game is an example of a game from the Random Game Mechanic Generator at
# The game mechanics this game uses are: Hidden Image / Where's Waldo?, Switch Modes, Avoiding Unkillable Objects

import random, sys, time, pygame, os
from pygame.locals import *

FPS = 45
WINDOWWIDTH = 640
WINDOWHEIGHT = 480

MAXHEALTH = 6
PLAYERMOVERATE = 10

MINFLAGSPEED = 2
MAXFLAGSPEED = 6
MAXNUMFLAGS = 16

FLAGSIZE = 32

INVULNTIME = 2       # how long the player is invulnerable after being hit in seconds
GAMEOVERTIME = 4     # how long the "game over" text stays on the screen in seconds


#                R    G    B
WHITE        = (255, 255, 255)
BLACK        = (  0,   0,   0)
RED          = (255,   0,   0)
BLUE         = (  0,   0, 255)
DARKGRAY     = ( 40,  40,  40)
bgColor = WHITE


def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT, BIGFONT

    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    pygame.display.set_caption('Simulate')

    BASICFONT = pygame.font.Font('freesansbold.ttf', 16)
    BIGFONT = pygame.font.Font('freesansbold.ttf', 72)
    infoSurf = BASICFONT.render('Match the pattern by clicking on the button or using the Q, W, A, S keys.', 1, DARKGRAY)
    infoRect = infoSurf.get_rect()
    infoRect.topleft = (10, WINDOWHEIGHT - 25)

    score = 0

    # load the flag images
    blueFlags = [pygame.image.load('blueflags\\' + filename) for filename in os.listdir('blueflags') if filename.endswith('.png')]
    redFlags  = [pygame.image.load('redflags\\' + filename) for filename in os.listdir('redflags')  if filename.endswith('.png')]
    allFlags = blueFlags + redFlags

    # resize all the flags
    for i in range(len(allFlags)):
        allFlags[i] = pygame.transform.smoothscale(allFlags[i], (FLAGSIZE, FLAGSIZE))

    gameOverSurf = BIGFONT.render('Game Over', True, DARKGRAY)
    gameOverRect = gameOverSurf.get_rect()
    gameOverRect.center = (int(WINDOWWIDTH / 2), int(WINDOWHEIGHT / 2))

    playerMode = 'red'
    health = MAXHEALTH
    playerDirection = 'left'
    playerBlueLeftImage = pygame.image.load('player_blue_left.png')
    playerBlueRightImage = pygame.image.load('player_blue_right.png')
    playerRedLeftImage = pygame.image.load('player_red_left.png')
    playerRedRightImage = pygame.image.load('player_red_right.png')

    playerRect = pygame.Rect(int(WINDOWWIDTH / 2), int(WINDOWHEIGHT / 2), 45, 45)

    boardFlags = []
    moveLeft = moveRight = moveUp = moveDown = False

    getNewTargetFlag = True

    invulnerableMode = False
    invulnerableStartTime = 0
    gameOverMode = False
    gameOverStartTime = 0

    while True: # main game loop
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT:
                terminate()

            elif event.type == KEYDOWN:
                if event.key in (K_UP, K_w):
                    moveDown = False
                    moveUp = True
                elif event.key in (K_DOWN, K_s):
                    moveUp = False
                    moveDown = True
                elif event.key in (K_LEFT, K_a):
                    moveRight = False
                    moveLeft = True
                    playerDirection = 'left'
                elif event.key in (K_RIGHT, K_d):
                    moveLeft = False
                    moveRight = True
                    playerDirection = 'right'
                elif event.key == K_SPACE:
                    if playerMode == 'red':
                        playerMode = 'blue'
                    elif playerMode == 'blue':
                        playerMode = 'red'

            elif event.type == KEYUP:
                # stop moving the player
                if event.key in (K_LEFT, K_a):
                    moveLeft = False
                elif event.key in (K_RIGHT, K_d):
                    moveRight = False
                elif event.key in (K_UP, K_w):
                    moveUp = False
                elif event.key in (K_DOWN, K_s):
                    moveDown = False

                elif event.key == K_ESCAPE:
                    terminate()

        DISPLAYSURF.fill(bgColor)

        # move the player
        if not gameOverMode:
            if moveUp:
                playerRect.y -= PLAYERMOVERATE
            if moveDown:
                playerRect.y += PLAYERMOVERATE
            if moveLeft:
                playerRect.x -= PLAYERMOVERATE
            if moveRight:
                playerRect.x += PLAYERMOVERATE

        if getNewTargetFlag:
            if random.randint(0, 1) == 0:
                targetFlagColor = 'blue'
                targetFlag = random.randint(0, len(blueFlags) - 1)
            else:
                targetFlagColor = 'red'
                targetFlag = random.randint(0, len(redFlags) - 1) + len(blueFlags)
            getNewTargetFlag = False

        # remove flags if they are too off the board
        for i in range(len(boardFlags) - 1, -1, -1):
            flagObj = boardFlags[i]
            if flagObj['rect'].x < -FLAGSIZE or flagObj['rect'].x > WINDOWWIDTH + FLAGSIZE:
                del boardFlags[i]

        # add flags if there need to be more
        while len(boardFlags) < MAXNUMFLAGS:
            boardFlags.append(getNewFlagObj(len(blueFlags), len(redFlags)))

        # move the flags around
        for flagObj in boardFlags:
            if flagObj['direction'] == 'right':
                flagObj['rect'].x += flagObj['speed']
            elif flagObj['direction'] == 'left':
                flagObj['rect'].x -= flagObj['speed']

            # draw the flags
            DISPLAYSURF.blit(allFlags[flagObj['flag']], flagObj['rect'])

        # draw player
        if not gameOverMode:
            if playerDirection == 'right' and playerMode == 'blue':
                DISPLAYSURF.blit(playerBlueRightImage, playerRect)
            elif playerDirection == 'left' and playerMode == 'blue':
                DISPLAYSURF.blit(playerBlueLeftImage, playerRect)
            elif playerDirection == 'right' and playerMode == 'red':
                DISPLAYSURF.blit(playerRedRightImage, playerRect)
            elif playerDirection == 'left' and playerMode == 'red':
                DISPLAYSURF.blit(playerRedLeftImage, playerRect)

        # draw health and status stuff
        drawHealthMeter(health)
        drawStatus(allFlags[targetFlag], score, playerMode)

        # check if player has hit a flag of the other color
        for flagObj in boardFlags:
            if flagObj['color'] != playerMode and not invulnerableMode and playerRect.colliderect(flagObj['rect']):
                health -= 1
                invulnerableMode = True
                invulnerableStartTime = time.time()
                if health == 0:
                    gameOverMode = True # turn on "game over mode"
                    gameOverStartTime = time.time()

            if flagObj['flag'] == targetFlag and flagObj['color'] == playerMode and playerRect.colliderect(flagObj['rect']):
                score += 1
                getNewTargetFlag = True

        # turn off invul mode
        if invulnerableMode and time.time() - invulnerableStartTime > INVULNTIME:
            invulnerableMode = False

        # restart game after a few seconds
        if gameOverMode and time.time() - gameOverStartTime > GAMEOVERTIME:
            return

        if gameOverMode:
            DISPLAYSURF.blit(gameOverSurf, gameOverRect)

        pygame.display.update()
        FPSCLOCK.tick(FPS)


def getNewFlagObj(numBlueFlags, numRedFlags):
    if random.randint(0, 1) == 0:
        startx = -20
        direction = 'right'
    else:
        startx = WINDOWWIDTH + 20
        direction = 'left'

    if random.randint(0, 1) == 0:
        color = 'blue'
        flag = random.randint(0, numBlueFlags - 1)
    else:
        color = 'red'
        flag = random.randint(0, numRedFlags - 1) + numBlueFlags

    return {'flag': flag,
            'color': color,
            'rect': pygame.Rect(startx, random.randint(0, WINDOWHEIGHT - FLAGSIZE), FLAGSIZE, FLAGSIZE),
            'direction': direction,
            'speed': random.randint(MINFLAGSPEED, MAXFLAGSPEED)}



def drawHealthMeter(currentHealth):
    for i in range(currentHealth): # draw red health bars
        pygame.draw.rect(DISPLAYSURF, RED,   (15, 5 + (10 * MAXHEALTH) - i * 10, 20, 10))
    for i in range(MAXHEALTH): # draw the white outlines
        pygame.draw.rect(DISPLAYSURF, BLACK, (15, 5 + (10 * MAXHEALTH) - i * 10, 20, 10), 1)

def drawStatus(lookingForFlagImage, score, mode):

    # draw "Looking for" text
    lookingForSurf = BASICFONT.render('Looking for:', 1, DARKGRAY)
    lookingForRect = lookingForSurf.get_rect()
    lookingForRect.bottomleft = (10, WINDOWHEIGHT - 10)
    DISPLAYSURF.blit(lookingForSurf, lookingForRect)

    # draw looking-for flag
    flagRect = lookingForFlagImage.get_rect()
    flagRect.bottomleft = (lookingForRect.right, WINDOWHEIGHT - 10)
    DISPLAYSURF.blit(lookingForFlagImage, flagRect)

    # draw score & "(space to change mode)"
    scoreSurf = BASICFONT.render('Score: %s (Space to change mode)' % score, 1, DARKGRAY)
    scoreRect = scoreSurf.get_rect()
    scoreRect.bottom = WINDOWHEIGHT
    scoreRect.centerx = int(WINDOWWIDTH / 2)
    DISPLAYSURF.blit(scoreSurf, scoreRect)

    # draw current mode
    c = mode == 'blue' and BLUE or RED
    modeSurf = BASICFONT.render('Can touch %s' % (mode.title()), 1, c, WHITE)
    modeRect = modeSurf.get_rect()
    modeRect.bottomright = (WINDOWWIDTH, WINDOWHEIGHT)
    DISPLAYSURF.blit(modeSurf, modeRect)

def terminate():
    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    while True:
        main()
