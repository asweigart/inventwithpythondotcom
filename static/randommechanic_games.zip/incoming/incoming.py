# Incoming!
# By Al Sweigart al@inventwithpython.com
# http://inventwithpython.com/blog
# Released under a "Simplified BSD" license

# The object of the game is to go through the orange portal as many times as possible while avoiding the bullets. Be careful though, because

# This game is an example of a game from the Random Game Mechanic Generator at
# The game mechanics this game uses are: Bouncing Objects, Bullet Hell, Teleports

import random, sys, time, pygame, os
from pygame.locals import *

FPS = 45
WINDOWWIDTH = 640
WINDOWHEIGHT = 480

MAXHEALTH = 6
PLAYERMOVERATE = 10

PORTALSIZE = 50

MINFLAGSPEED = 2
MAXFLAGSPEED = 6
MAXNUMFLAGS = 16

FLAGSIZE = 32

TURRETFIRINGSPEED = 0.75

BULLETSPEED = 5
BULLETSIZE = 6
MAXBULLETS = 16

#                R    G    B
WHITE        = (255, 255, 255)
BLACK        = (  0,   0,   0)
DARKGRAY     = ( 40,  40,  40)
BLUE = (2, 162, 248)
ORANGE = (250, 193, 0)
YELLOW   = (255, 255,   0)
RED = (255, 0, 0)
bgColor = WHITE

topscore = 0

def main():
    global FPSCLOCK, DISPLAYSURF, BASICFONT, BIGFONT, topscore

    pygame.init()
    FPSCLOCK = pygame.time.Clock()
    DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
    pygame.display.set_caption('Incoming!')

    BASICFONT = pygame.font.Font('freesansbold.ttf', 16)
    BIGFONT = pygame.font.Font('freesansbold.ttf', 72)
    infoSurf = BASICFONT.render('Match the pattern by clicking on the button or using the Q, W, A, S keys.', 1, DARKGRAY)
    infoRect = infoSurf.get_rect()
    infoRect.topleft = (10, WINDOWHEIGHT - 25)

    score = 0


    moveLeft = moveRight = moveUp = moveDown = False
    playerDirection = 'left'
    playerLeftImage = pygame.image.load('player_left.png')
    playerRightImage = pygame.image.load('player_right.png')
    playerRect = playerLeftImage.get_rect()
    playerRect.center = (int(WINDOWWIDTH / 2), int(WINDOWHEIGHT / 2))

    gameOverMode = False
    teleportPortals = True

    bluePortalSurf = pygame.Surface((PORTALSIZE, PORTALSIZE))
    bluePortalSurf.fill(bgColor)
    pygame.draw.circle(bluePortalSurf, BLUE, (int(PORTALSIZE / 2), int(PORTALSIZE / 2)), int(PORTALSIZE / 2), 6)
    bluePortalRect = bluePortalSurf.get_rect()

    orangePortalSurf = pygame.Surface((PORTALSIZE, PORTALSIZE))
    orangePortalSurf.fill(bgColor)
    pygame.draw.circle(orangePortalSurf, ORANGE, (int(PORTALSIZE / 2), int(PORTALSIZE / 2)), int(PORTALSIZE / 2) , 6)
    orangePortalRect = orangePortalSurf.get_rect()

    dontTeleport = False

    turretImage = pygame.image.load('turret.png')
    turretRect = turretImage.get_rect()
    turretRect.left = random.randint(0, WINDOWWIDTH - turretRect.width)
    turretRect.top = random.randint(0, WINDOWHEIGHT - turretRect.height)

    lastFireTime = time.time()

    bullets = []

    while True: # main game loop
        for event in pygame.event.get(): # event handling loop
            if event.type == QUIT:
                terminate()

            elif event.type == KEYDOWN:
                if event.key in (K_UP, K_w):
                    moveDown = False
                    moveUp = True
                elif event.key in (K_DOWN, K_s):
                    moveUp = False
                    moveDown = True
                elif event.key in (K_LEFT, K_a):
                    moveRight = False
                    moveLeft = True
                    playerDirection = 'left'
                elif event.key in (K_RIGHT, K_d):
                    moveLeft = False
                    moveRight = True
                    playerDirection = 'right'
                elif event.key == K_SPACE:
                    if playerMode == 'red':
                        playerMode = 'blue'
                    elif playerMode == 'blue':
                        playerMode = 'red'

            elif event.type == KEYUP:
                # stop moving the player
                if event.key in (K_LEFT, K_a):
                    moveLeft = False
                elif event.key in (K_RIGHT, K_d):
                    moveRight = False
                elif event.key in (K_UP, K_w):
                    moveUp = False
                elif event.key in (K_DOWN, K_s):
                    moveDown = False

                elif event.key == K_ESCAPE:
                    terminate()

        DISPLAYSURF.fill(bgColor)

        # move the portals if needed
        if teleportPortals:
            bluePortalRect.center   = (random.randint(PORTALSIZE, WINDOWWIDTH - PORTALSIZE), random.randint(PORTALSIZE, WINDOWHEIGHT - PORTALSIZE))
            orangePortalRect.center = (random.randint(PORTALSIZE, WINDOWWIDTH - PORTALSIZE), random.randint(PORTALSIZE, WINDOWHEIGHT - PORTALSIZE))
            teleportPortals = False

        # move the player
        if moveUp and playerRect.top > 0:
            playerRect.y -= PLAYERMOVERATE
        if moveDown and playerRect.bottom < WINDOWHEIGHT:
            playerRect.y += PLAYERMOVERATE
        if moveLeft and playerRect.left > 0:
            playerRect.x -= PLAYERMOVERATE
        if moveRight and playerRect.right < WINDOWWIDTH:
            playerRect.x += PLAYERMOVERATE


        # add a bullets if it is time to fire (and remove the last one if the max has been reached)
        if time.time() - TURRETFIRINGSPEED > lastFireTime and random.randint(0, 10) == 0:
            lastFireTime = time.time()
            bullets.append(getNewBulletObj(turretRect.centerx, turretRect.centery))
            if len(bullets) > MAXBULLETS:
                del bullets[0]


        # check if gone through the orange portal
        if playerRect.colliderect(orangePortalRect):
            if not dontTeleport:
                playerRect.center = bluePortalRect.center
                score += 1
                if score > topscore:
                    topscore = score
            dontTeleport = True
            teleportPortals = True
        elif not playerRect.colliderect(bluePortalRect):
            dontTeleport = False

        # move bullets
        for bulletObj in bullets:
            # check if the bullet is hitting the player
            r = pygame.Rect(0, 0, BULLETSIZE * 2, BULLETSIZE * 2)
            r.center = (bulletObj['x'], bulletObj['y'])
            if r.colliderect(playerRect):
                gameOverMode = True


            # check if bouncing off the wall
            if bulletObj['x'] < 0:
                bulletObj['speedx'] = abs(bulletObj['speedx'])
            if bulletObj['x'] > WINDOWWIDTH:
                bulletObj['speedx'] = -abs(bulletObj['speedx'])
            if bulletObj['y'] < 0:
                bulletObj['speedy'] = abs(bulletObj['speedy'])
            if bulletObj['y'] > WINDOWHEIGHT:
                bulletObj['speedy'] = -abs(bulletObj['speedy'])

            # check if it is on a portal
            if pygame.Rect(bulletObj['x'], bulletObj['y'], BULLETSIZE * 2, BULLETSIZE * 2).colliderect(orangePortalRect):
                bulletObj['x'], bulletObj['y'] = bluePortalRect.center
                if bulletObj['speedx'] < 0:
                    bulletObj['x'] -= PORTALSIZE - 4
                if bulletObj['speedx'] > 0:
                    bulletObj['x'] += PORTALSIZE - 4
                if bulletObj['speedy'] < 0:
                    bulletObj['y'] -= PORTALSIZE - 4
                if bulletObj['speedy'] > 0:
                    bulletObj['y'] += PORTALSIZE - 4
            elif pygame.Rect(bulletObj['x'], bulletObj['y'], BULLETSIZE * 2, BULLETSIZE * 2).colliderect(bluePortalRect):
                bulletObj['x'], bulletObj['y'] = orangePortalRect.center
                if bulletObj['speedx'] < 0:
                    bulletObj['x'] -= PORTALSIZE - 4
                if bulletObj['speedx'] > 0:
                    bulletObj['x'] += PORTALSIZE - 4
                if bulletObj['speedy'] < 0:
                    bulletObj['y'] -= PORTALSIZE - 4
                if bulletObj['speedy'] > 0:
                    bulletObj['y'] += PORTALSIZE - 4

            bulletObj['x'] += bulletObj['speedx']
            bulletObj['y'] += bulletObj['speedy']

        # draw portals
        DISPLAYSURF.blit(bluePortalSurf, bluePortalRect)
        DISPLAYSURF.blit(orangePortalSurf, orangePortalRect)

        # draw turret
        DISPLAYSURF.blit(turretImage, turretRect)

        # draw score
        scoreSurf = BASICFONT.render('Number of times through the orange portal: %s' % (score), 1, DARKGRAY)
        scoreRect = scoreSurf.get_rect()
        scoreRect.bottomleft = (10, WINDOWHEIGHT - 10)
        DISPLAYSURF.blit(scoreSurf, scoreRect)

        topscoreSurf = BASICFONT.render('Top score: %s' % (topscore), 1, DARKGRAY)
        topscoreRect = topscoreSurf.get_rect()
        topscoreRect.bottomright = (WINDOWWIDTH - 10, WINDOWHEIGHT - 10)
        DISPLAYSURF.blit(topscoreSurf, topscoreRect)

        # draw bullets
        for bulletObj in bullets:
            pygame.draw.circle(DISPLAYSURF, RED, (bulletObj['x'], bulletObj['y']), BULLETSIZE)

        # draw player
        if playerDirection == 'left':
            DISPLAYSURF.blit(playerLeftImage, playerRect)
        elif playerDirection == 'right':
            DISPLAYSURF.blit(playerRightImage, playerRect)

        if gameOverMode:
            for i in range(80):
                pygame.draw.circle(DISPLAYSURF, RED, (playerRect.centerx, playerRect.centery), i)
                pygame.display.update()
            for i in range(80):
                pygame.draw.circle(DISPLAYSURF, WHITE, (playerRect.centerx, playerRect.centery), i)
                pygame.display.update()
            time.sleep(0.5)
            return

        pygame.display.update()
        FPSCLOCK.tick(FPS)


def getNewBulletObj(turretX, turretY):
    speedx = random.randint(-BULLETSPEED, BULLETSPEED)
    if speedx == 0: speedx = 1 # just to prevent having both a speedx and speedy of 0.

    return {'x': turretX, 'y': turretY,
            'speedx': speedx,
            'speedy': random.randint(-BULLETSPEED, BULLETSPEED)}


def terminate():
    pygame.quit()
    sys.exit()

if __name__ == '__main__':
    while True:
        main()
