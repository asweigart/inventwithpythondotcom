def foo():
    foo()

foo()