numberOfEggs = 12
if numberOfEggs < 4:
    print('That is not that many eggs.')
elif numberOfEggs < 20:
    print('You have quite a few eggs.')
elif numberOfEggs == 144:
    print('You have a lot of eggs. Gross!')
else:
    print('Eat ALL the eggs!')
