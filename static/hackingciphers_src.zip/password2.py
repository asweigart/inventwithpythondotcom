print('What is the password?')
password = input()
if password == 'rosebud':
    print('Access granted.')
else:
    print('Access denied.')
print('Done.')
